# Financial-Modeling-and-Analysis-in-Excel
Excel practice workbook in financial modeling and analysis inspired by Corporate Finance Institute online course
* Formulas, functions, shortcuts, and best practices required for financial modeling and analysis in Excel
